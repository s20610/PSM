package gof;

public interface DisplayDriver {
    void displayBoard(Board board);
}